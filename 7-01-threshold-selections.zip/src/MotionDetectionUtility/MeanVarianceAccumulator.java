package MotionDetectionUtility;

public class MeanVarianceAccumulator {
	private double mean;
	private double variance;
	private double sumOfSquares;
	private int count;
	private double p = 0.5;
	
	public MeanVarianceAccumulator(){
		this.mean = 0;
		this.variance = 0;
		this.count = 0;
		this.sumOfSquares = 0;
	}
	
	public void accumulate(int x){
//		if(this.variance == 0){
//		double sum = this.mean * this.count;
//		this.count ++;
//		this.mean = (sum+x) / this.count;
//		this.sumOfSquares = this.sumOfSquares + x*x;
//		this.variance = this.sumOfSquares / this.count - this.mean * this.mean;
//		}else{
		this.p = 0.5*(1.0f/Math.sqrt(2*Math.PI*this.variance)) * Math.exp(-((x-this.mean)*(x-this.mean))/(2*this.variance));
		this.mean = (1-p)*this.mean + p*this.mean;
		this.variance = (1-p)*this.variance + p*(x-this.mean)*(x-this.mean);
//		System.out.println("Mean: "+this.mean+" Variance: "+this.variance);
//		}
	}
	
	public double getMean(){
		return this.mean;
	}
	
	public double getVariance(){
		return this.variance;
	}
	
	public double getSumOfSquares(){
		return this.sumOfSquares;
	}
	
	public int getCount(){
		return this.count;
	}
	
	public boolean isDataWithinConfidenceInterval(int data){
		double std = Math.sqrt(this.variance);
		
		if(data >= this.mean - 5*std &&
				data <= this.mean + 5*std){
			return true;
		}else{
			return false;
		}
	}
}