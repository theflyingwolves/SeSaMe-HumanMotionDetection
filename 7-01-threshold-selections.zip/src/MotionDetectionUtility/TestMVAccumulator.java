package MotionDetectionUtility;

public class TestMVAccumulator {
	public static void main(String[] args){
		MeanVarianceAccumulator mv = new MeanVarianceAccumulator();
		mv.accumulate(1);
		mv.accumulate(2);
		mv.accumulate(3);
		print(mv);
		mv.accumulate(4);
		print(mv);
		mv.accumulate(0);
		print(mv);
	}
	
	private static void print(MeanVarianceAccumulator mv){
		System.out.println("Mean: "+mv.getMean()+" Variance: "+mv.getVariance());
	}
}
