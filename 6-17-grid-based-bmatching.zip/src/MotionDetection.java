import org.opencv.core.Core;
import org.opencv.core.Mat;

import MotionDetectionUtility.VideoDisplayer;
import MotionDetectionUtility.VideoLoader;
import VideoProcessor.Frame;
import VideoProcessor.VideoProcessor;

 public class MotionDetection{
   public static void main(String arg[]){  
	    System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
//	    String fileName = "/Users/theflyingwolves/Documents/Android/OpenCV/MotionDetection/video/movingBall.mp4";
	    String fileName = "/Users/theflyingwolves/Desktop/raiseHand.mp4";
//	    String fileName = "/Users/theflyingwolves/Documents/Android/OpenCV/MotionDetection/video/raiseHand.mp4";
//	    String fileName = "/Users/theflyingwolves/Documents/Android/OpenCV/MotionDetection/src/camelEating.mp4";
//	    VideoDisplayer player= new VideoDisplayer(fileName);
//	    player.play();
	    
	    VideoLoader loader = new VideoLoader(fileName);
	    VideoProcessor processor = new VideoProcessor();
	    while(!loader.isEndOfVideo()){
	    	Mat frame = loader.getFrameAsMat();
	    	processor.processFrame(frame);
	    }
	    return;
   }
 }