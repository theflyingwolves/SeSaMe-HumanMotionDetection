package MotionDetectionUtility;

import org.opencv.core.Point;

public class Vector {
	private Point vector;
	public Vector(double dx, double dy){
		vector = new Point(dx,dy);
	}
	
	public int dx(){
		return (int)vector.x;
	}
	
	public int dy(){
		return (int)vector.y;
	}
	
	public Vector getNormedVector(){
		double length = Math.sqrt(vector.x*vector.x+vector.y*vector.y) / 50;
		return new Vector(vector.x/length, vector.y / length);
	}
	
	public Vector add(Vector v){
		return new Vector(this.dx()+v.dx(),this.dy()+v.dy());
	}
}