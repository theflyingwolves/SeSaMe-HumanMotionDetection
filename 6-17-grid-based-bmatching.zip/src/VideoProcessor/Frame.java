package VideoProcessor;

import java.util.ArrayList;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;

import MotionDetectionUtility.Vector;

public class Frame {
	private final static double NEIGHBOUR_AREA_RADIUS = 3;
	
	private ArrayList<Grid> gridArray;
	private ArrayList<Grid> significantGridArray;
	private Mat frameAsMat;
	private int numOfRows;
	private int numOfCols;
	
	public Frame(Mat mat,int numOfRows,int numOfCols){
		this.frameAsMat = mat;
		this.numOfRows = numOfRows;
		this.numOfCols = numOfCols;
		this.significantGridArray = new ArrayList<Grid>();
		initGridArray();
//		initFrameGridBorder();
	}
	
	private void initGridArray(){
		if(gridArray == null){
			gridArray = new ArrayList<Grid>();
		}
		if(frameAsMat != null){
			Grid grid;
			int gridHeight = frameAsMat.rows() / this.numOfRows;
			int gridWidth = frameAsMat.cols() / this.numOfCols;
			
			for(int y= 0; y < this.numOfRows;y++){
				for(int x = 0; x < this.numOfCols; x++){
					int topX = x * gridWidth;
					int topY = y * gridHeight;
					int lowerX = (x+1) * gridWidth;
					int lowerY = (y+1) * gridHeight;
					grid = new Grid(new Point(topX,topY), new Point(lowerX, lowerY));
					grid.setRowColIndices(y, x);
					this.gridArray.add(grid);
				}
			}
		}
	}
	
	public Grid getGridIndexedBy(int index){
//		int rowNum = (int)index / this.numOfCols;
//		int colNum = index - rowNum * this.numOfCols;
//		Grid grid = gridArray.get(index);
//		System.out.println("Retrieving grid at row "+rowNum+" col "+colNum);
//		System.out.println("Getting grid at row "+grid.getRowIndex()+" col "+grid.getColIndex());
		return gridArray.get(index);
	}
	
	public int getIndexForGrid(Grid grid){
		int rowIndex = grid.getRowIndex();
		int colIndex = grid.getColIndex();
		return rowIndex*this.numOfCols+colIndex;
	}
	
	private void initFrameGridBorder(){
		if(this.gridArray.size() > 0){
			Scalar borderColor = new Scalar(255,255,255);
			for(Grid grid : this.gridArray){
				Core.rectangle(frameAsMat, grid.getTopLeftCorner(), grid.getLowerRightCorner(), borderColor);
			}
		}
	}
	
	public void updateGridMovingPosition(){
		for(Grid grid : this.gridArray){
			Vector dir = grid.getMovingDirection().getNormedVector();
			Point center = grid.getCenter();
			Point endPoint = new Point(center.x+dir.dx(), center.y+dir.dy());
			Core.line(frameAsMat, center, endPoint, new Scalar(0,0,255));
		}
	}
	
	public void updateAverageMovingDirection(){
		Vector movDir = new Vector(0,0);
		for(Grid grid : this.gridArray){
			Vector dir = grid.getMovingDirection().getNormedVector();
			movDir = movDir.add(dir);
		}
		Point center = new Point(this.frameAsMat.cols()/2,this.frameAsMat.rows()/2);
		Point end = new Point(center.x+movDir.dx(), center.y+movDir.dy());
		Core.line(frameAsMat, center, end, new Scalar(0,0,255));
	}
	
	public Mat getFrameAsMat(){
		return this.frameAsMat;
	}
	
	public ArrayList<Grid> getGridArray(){
		return this.gridArray;
	}
	
	public void setSignificantGridArray(ArrayList<Grid> sigGridArray){
		this.significantGridArray = sigGridArray;
	}
	
	public ArrayList<Grid> getSignificantGridArray(){
		return this.significantGridArray;
	}
	
	/**
	 * 
	 * @param grid1
	 * @param grid2
	 * @return Defines what it means by being 
	 */
	public static boolean areGridsNear(Grid grid1, Grid grid2){
		int row1 = grid1.getRowIndex();
		int row2 = grid2.getRowIndex();
		int col1 = grid1.getColIndex();
		int col2 = grid2.getColIndex();
		
		if(Math.abs(row1-row2)<=NEIGHBOUR_AREA_RADIUS && Math.abs(col1-col2)<=NEIGHBOUR_AREA_RADIUS){
			return true;
		}else{
			return false;
		}
	}
}