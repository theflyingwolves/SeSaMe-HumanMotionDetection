package VideoProcessor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import BipartiteMatching.Edge;
import BipartiteMatching.HungarianMatch;
import MotionDetectionUtility.BufferQueue;
import MotionDetectionUtility.DisplayWindow;
import MotionDetectionUtility.Utility;
import MotionDetectionUtility.Vector;

public class VideoProcessor {
	private final int BUFFER_SIZE = 2;
	private final int PROCESSOR_FREQUENCY = 50;
	private final int MINIMUM_NUM_OF_FEATURES_IN_ACCEPTED_GRID = 2;
	private final int NUMBER_OF_GRIDS_PER_ROW = 50;
	private final int NUMBER_OF_GRIDS_PER_COL = 50;
	private final int GOOD_FEATURE_CIRCLE_RADIUS = 5;
	private final int MAX_NUM_OF_FEATURES = 800;
	private final int MIN_FEATURES_DISTANCE = 10;
	private final double FEATURE_QUALITY_THREASHOLD = 0.005;
	
	private BufferQueue<Frame> buffer;
	private Timer timer;
	private DisplayWindow window;
	
	public VideoProcessor(){
		buffer = new BufferQueue<Frame>(this.BUFFER_SIZE);
		timer = new Timer();
		window = new DisplayWindow();
		timer.schedule(new Processor(), 0, PROCESSOR_FREQUENCY);
	}
	
	public void processFrame(Mat newFrame){
		boolean success = buffer.add(new Frame(newFrame,NUMBER_OF_GRIDS_PER_ROW,NUMBER_OF_GRIDS_PER_COL));
		while(!success){
			success =  buffer.add(new Frame(newFrame,NUMBER_OF_GRIDS_PER_ROW,NUMBER_OF_GRIDS_PER_COL));
		}
	}
	
	class Processor extends TimerTask {
		public void run() {
			if(buffer.size() > 0){
				Frame frame = buffer.getLatest();
				Frame prevFrame = buffer.getSecondLatest();
				buffer.removeOldest();
				if(prevFrame == null){
					// If there is no previous frame, no processing is required
					return ;
				}
				
				if(frame != null){
					process(frame,prevFrame);
					frame.updateGridMovingPosition();
					frame.updateAverageMovingDirection();
					window.setSize(frame.getFrameAsMat().width(), frame.getFrameAsMat().height());
					window.showFrame(Utility.matToBufferedImage(frame.getFrameAsMat()));
				}
			}
		}
		
		private void process(Frame currFrame,Frame prevFrame){
			ArrayList<Grid> currSignificantGridArray = getSignificantGridArrayForFrame(currFrame);
			ArrayList<Grid> prevSignificantGridArray = prevFrame.getSignificantGridArray();
			Map<Edge<Grid>,Double> graph = buildGraphUsingSignificantGridArrays(currSignificantGridArray,
																				prevSignificantGridArray);
			HungarianMatch<Grid> hMatch = new HungarianMatch<Grid>(graph);
			Map<Grid,Grid> minCostMatch = hMatch.getMinCostMatch();
			updateMovingDirections(minCostMatch);
		}
		
		private void updateMovingDirections(Map<Grid,Grid> match){
			for(Grid grid : match.keySet()){
				Grid mappedGrid = match.get(grid);
				double dx = mappedGrid.getTopLeftCorner().x - grid.getTopLeftCorner().x;
				double dy = mappedGrid.getTopLeftCorner().y - grid.getTopLeftCorner().y;
				grid.setMovingDirection(new Vector(dx,dy));
			}
		}
		
		private Map<Edge<Grid>,Double> buildGraphUsingSignificantGridArrays(ArrayList<Grid> currSignificantGridArray,
																				ArrayList<Grid> prevSignificantGridArray){
			Map<Edge<Grid>,Double> graph = new HashMap<Edge<Grid>,Double>();
			
			if(currSignificantGridArray != null && currSignificantGridArray.size() > 0){
				if(prevSignificantGridArray != null && prevSignificantGridArray.size() > 0){
					for(Grid currGrid : currSignificantGridArray){
						for(Grid prevGrid : prevSignificantGridArray){
							if(Frame.areGridsNear(currGrid, prevGrid)){
								graph.put(new Edge<Grid>(currGrid,prevGrid), (double)getEdgeWeightBetweenGrids(currGrid,prevGrid));
							}else{
								graph.put(new Edge<Grid>(currGrid,prevGrid), (double)255);
							}
						}
					}
				}
			}
			
			return graph;
		}
		
		private ArrayList<Grid> getSignificantGridArrayForFrame(Frame frame){
			Point[] goodFeatures = getGoodFeaturesFromFrame(frame);
			drawCircleAroundGoodFeatures(goodFeatures,frame);
			assignGoodFeaturesToGrids(goodFeatures,frame);
			ArrayList<Grid> originalGridArray = frame.getGridArray();
			ArrayList<Grid> significantGridArray = filterGrids(originalGridArray);
			frame.setSignificantGridArray(significantGridArray);
			return significantGridArray;
		}
		
		private Point[] getGoodFeaturesFromFrame(Frame frame){
			Imgproc.cvtColor(frame.getFrameAsMat(), frame.getFrameAsMat(),Imgproc.COLOR_BGR2GRAY);
			MatOfPoint goodFeaturesAsMatrix = new MatOfPoint();
			Imgproc.goodFeaturesToTrack(frame.getFrameAsMat(), goodFeaturesAsMatrix, MAX_NUM_OF_FEATURES, FEATURE_QUALITY_THREASHOLD, MIN_FEATURES_DISTANCE);
			return goodFeaturesAsMatrix.toArray();
		}
		
		private void drawCircleAroundGoodFeatures(Point[] goodFeatures,Frame frame){
			for(int i=0;i<goodFeatures.length;i++){
				Point goodFeature = goodFeatures[i];
				Core.circle(frame.getFrameAsMat(), goodFeature, GOOD_FEATURE_CIRCLE_RADIUS, new Scalar(0,0,0));
			}
		}
		
		/**
		 * @param grids
		 * 		Array of grids to be filtered
		 * @returns
		 * 		Significant grids with the criteria that the number of features in the grid is more than
		 * 		the threshold MINIMUM_NUM_OF_FEATURES_IN_ACCEPTED_GRID given.
		 */
		private ArrayList<Grid> filterGrids(ArrayList<Grid> grids){
			ArrayList<Grid> significantGrids = new ArrayList<Grid> ();
			for(Grid grid : grids){
				if(grid.getGoodFeatures().size() >= MINIMUM_NUM_OF_FEATURES_IN_ACCEPTED_GRID){
					significantGrids.add(grid);
				}
			}

			return significantGrids;
		}
		
		/**
		 * @return
		 * 		Assign the array of feature points to the corresponding grid in the given frame.
		 * 		The feature for each grid is stored inside the corresponding Grid object
		 */
		private void assignGoodFeaturesToGrids(Point[] features, Frame frame){
			ArrayList<Grid> gridArray = frame.getGridArray();
			for(Grid grid : gridArray){
				for(Point feature : features){
					if(grid.isPointWithinGrid(feature)){
						grid.assignGoodFeature(feature, frame.getFrameAsMat());
					}
				}
			}
		}
		
		/**
		 * 
		 * @param grid1
		 * @param grid2
		 * @return The edge between the two grids determined by max(minMatch Weights), where minMatch Weight
		 * 			represents the individual edge weight in a minimum match
		 */
		private int getEdgeWeightBetweenGrids(Grid grid1, Grid grid2){
			ArrayList<Integer> goodFeaturesGrid1 = grid1.getGoodFeatures();
			ArrayList<Integer> goodFeaturesGrid2 = grid2.getGoodFeatures();	
			
			Edge<Integer> edge;
			Map<Edge<Integer>,Double> graph = new HashMap<Edge<Integer>,Double>();
			for(Integer gf1 : goodFeaturesGrid1){
				for(Integer gf2 : goodFeaturesGrid2){
					edge = new Edge<Integer>(gf1,gf2);
					graph.put(edge, (double)Math.abs(gf1-gf2));
				}
			}
			
			HungarianMatch<Integer> hMatch = new HungarianMatch<Integer>(graph);
			return (int)hMatch.getMaxCost();
		}
	}
}