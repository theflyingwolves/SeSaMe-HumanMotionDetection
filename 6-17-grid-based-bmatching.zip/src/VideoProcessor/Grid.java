package VideoProcessor;

import java.util.ArrayList;

import org.opencv.core.Mat;
import org.opencv.core.Point;

import MotionDetectionUtility.Vector;

public class Grid {
	private ArrayList<Integer> goodFeatures;
	private Point topLeftCorner;
	private Point lowerRightCorner;
	private Vector movingDirection;
	private int goodMeasure;
	private int row,col;
	
	public Grid(Point topLeftCorner, Point lowerRightCorner){
		this.movingDirection = new Vector(0,0);
		this.topLeftCorner = topLeftCorner;
		this.lowerRightCorner = lowerRightCorner;
		this.goodFeatures = new ArrayList<Integer>();
	}
	
	public void assignGoodFeature(Point goodFeature, Mat mat){
		if(this.goodFeatures == null){
			this.goodFeatures = new ArrayList<Integer>();
		}
		double[] pixel = mat.get((int)goodFeature.x, (int)goodFeature.y);
		if(pixel != null){
			this.goodFeatures.add((int)pixel[0]);
		}
	}
	
	public ArrayList<Integer> getGoodFeatures(){
		return this.goodFeatures;
	}
	
	public void increaseMeasure(){
		this.goodMeasure += 1;
	}
	
	public void decreaseMeasure(){
		this.goodMeasure -= 1;
	}
	
	public void setMovingDirection(Vector dir){
		this.movingDirection = dir;
	}
	
	public Vector getMovingDirection(){
		return this.movingDirection;
	}
	
	public Point getCenter(){
		double midX = (this.topLeftCorner.x + this.lowerRightCorner.x ) / 2;
		double midY = (this.topLeftCorner.y + this.lowerRightCorner.y ) / 2;
		return new Point(midX, midY);
	}
	
	public Point getTopLeftCorner(){
		return this.topLeftCorner;
	}
	
	public Point getLowerRightCorner(){
		return this.lowerRightCorner;
	}
	
	public boolean isPointWithinGrid(Point pt){
		if(pt.x >= this.topLeftCorner.x && pt.x <= this.lowerRightCorner.x){
			if(pt.y >= this.topLeftCorner.y && pt.y <= this.lowerRightCorner.y){
				return true;
			}
		}
		return false;
	}
	
	public void setRowColIndices(int row, int col){
		this.row = row;
		this.col = col;
	}
	
	public int getRowIndex(){
		return this.row;
	}
	
	public int getColIndex(){
		return this.col;
	}
	
	public String toString(){
		return "(("+topLeftCorner.x + ", "+topLeftCorner.y+"), ("+lowerRightCorner.x+", "+lowerRightCorner.y+"))";
	}
	
	public int hashCode(){
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj){
		if(!(obj instanceof Grid)){
			return false;
		}
		
		if(obj == this){
			return true;
		}
		
		Grid objGrid = (Grid)obj;
		return objGrid.toString().equalsIgnoreCase(this.toString());
	}
}