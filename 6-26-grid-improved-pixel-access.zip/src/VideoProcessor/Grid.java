package VideoProcessor;

import java.util.ArrayList;

import org.opencv.core.Mat;
import org.opencv.core.Point;

import MotionDetectionUtility.Vector;

public class Grid {
	private Point topLeftCorner;
	private Point lowerRightCorner;
	private Vector movingDirection;
	private int row,col;
	private int sum;
	private int pixelCount;
	private ArrayList<Integer> gridPixels;
	
	public Grid(Point topLeftCorner, Point lowerRightCorner){
		this.movingDirection = new Vector(0,0);
		this.topLeftCorner = topLeftCorner;
		this.lowerRightCorner = lowerRightCorner;
		this.sum = 0;
		this.pixelCount = 0;
		this.gridPixels = new ArrayList<Integer>();
	}
	
	public void assignPixelsInMat(Mat mat, double[] matAsArr, int numOfPixelsPerRow){
		int sum = 0;
		int pixel;
		this.gridPixels = new ArrayList<Integer>();
		this.pixelCount = 0;
		
		for(int row = (int)topLeftCorner.y; row<lowerRightCorner.y; row++){
			for(int col = (int)topLeftCorner.x; col<lowerRightCorner.x;col++){
				int index = row*numOfPixelsPerRow+col;
				pixel = (int)matAsArr[index];
				this.gridPixels.add(pixel);
				this.pixelCount++;
				sum += pixel;
			}
		}
		this.sum = sum;
	}
	
	public void assignPixelsInFrameArray(int[][] frameAsArr){
		int sum = 0;
		int pixel;
		this.pixelCount = 0;
		this.gridPixels = new ArrayList<Integer>();
		
		for(int row = (int)topLeftCorner.y; row<lowerRightCorner.y; row++){
			for(int col = (int)topLeftCorner.x; col<lowerRightCorner.x;col++){
				pixel = frameAsArr[row][col];
				this.gridPixels.add(pixel);
				this.pixelCount++;
				sum += pixel;
			}
		}
		
		this.sum = sum;
	}
	
	public int getAverageGrayScaleValue(){
		if(this.pixelCount == 0){
			return 0;
		}
		return this.sum / this.pixelCount;
	}
	
	public void setMovingDirection(Vector dir){
		this.movingDirection = dir;
	}
	
	public Vector getMovingDirection(){
		return this.movingDirection;
	}
	
	public Point getCenter(){
		double midX = (this.topLeftCorner.x + this.lowerRightCorner.x ) / 2;
		double midY = (this.topLeftCorner.y + this.lowerRightCorner.y ) / 2;
		return new Point(midX, midY);
	}
	
	public Point getTopLeftCorner(){
		return this.topLeftCorner;
	}
	
	public Point getLowerRightCorner(){
		return this.lowerRightCorner;
	}
	
	public boolean isPointWithinGrid(Point pt){
		if(pt.x >= this.topLeftCorner.x && pt.x <= this.lowerRightCorner.x){
			if(pt.y >= this.topLeftCorner.y && pt.y <= this.lowerRightCorner.y){
				return true;
			}
		}
		return false;
	}
	
	public ArrayList<Integer> getGridPixels(){
		return this.gridPixels;
	}
	
	public void setRowColIndices(int row, int col){
		this.row = row;
		this.col = col;
	}
	
	public int getRowIndex(){
		return this.row;
	}
	
	public int getColIndex(){
		return this.col;
	}
	
	public String toString(){
		return "(("+topLeftCorner.x + ", "+topLeftCorner.y+"), ("+lowerRightCorner.x+", "+lowerRightCorner.y+"))";
	}
	
	public int hashCode(){
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj){
		if(!(obj instanceof Grid)){
			return false;
		}
		
		if(obj == this){
			return true;
		}
		
		Grid objGrid = (Grid)obj;
		return objGrid.toString().equalsIgnoreCase(this.toString());
	}
}